<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-- ------------------------------------------------------------------------------------------------------------
    ------------------------------------- INICIO ITred Numero text .PHP --------------------------------------
    ------------------------------------------------------------------------------------------------------------- -->
<!-- TÍTULO: CAMPO OCULTO PARA TOTAL EN TEXTO -->

    <input type="hidden" id="total-en-texto" name="total-en-texto">

    <!-- Campo oculto para almacenar el total en texto -->
 
<!-- TÍTULO: DIV PARA MOSTRAR TOTAL EN TEXTO -->

    <div id="total-en-texto-display"></div>

    <!-- Elemento para mostrar el total en texto -->

<!-- TÍTULO: PÁRRAFO PARA TOTAL EN TEXTO -->

    <p id="total-en-texto" name="total-en-texto"></p>

    <!-- Párrafo que muestra el total en texto -->

<!-- TÍTULO: SCRIPT PARA CONVERTIR NÚMERO A TEXTO -->

    <script src="../../../js/editor_elemento/menu1_inicio/crear_nuevo/editor_menu2/menu2/boton1_nueva_cotizacion/numero_text.js"></script>

<!-- Enlaza el script para convertir el número a texto -->
     <!-- ------------------------------------------------------------------------------------------------------------
    -------------------------------------- FIN ITred Numero text  .PHP ----------------------------------------
    ------------------------------------------------------------------------------------------------------------- -->

<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->
