<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-- ------------------------------------------------------------------------------------------------------------
    ------------------------------------- INICIO ITred Spa Detalle encargado .PHP --------------------------------------
 ------------------------------------------------------------------------------------------------------------- -->

<!-- TITULO: AQUÍ INICIA EL HTML -->

    <!-- INICIO HTML -->

<!-- TÍTULO: IMPORTACIÓN DE ARCHIVO .CSS -->
    <!-- Llama al archivo CSS -->
<link rel="stylesheet" href="../../../../../css/menu_principal/crear_nuevo/menu_2_programas/boton5_ver_cotizacion/detalle_encargado.css">

<!---------- DETALLE DEL ENCARGADO -------->

 <div class="section">
    <h3>DETALLES DEL ENCARGADO</h3>
    <div class="info">
        <p><strong>Nombre:</strong> <?php echo $nombre_encargado; ?></p>
        <p><strong>Email:</strong> <?php echo $email_encargado; ?></p>
        <p><strong>Teléfono:</strong> <?php echo $fono_encargado; ?></p>
        <p><strong>Celular:</strong> <?php echo $celular_encargado; ?></p>
    </div>
</div>

<!-- TÍTULO: IMPORTACIÓN DE ARCHIVO .JS -->
    <!-- Llama al archivo JS -->
    <script src="../../../../../js/menu_principal/crear_nuevo/ver_cotizacion/datos_encargado.js"></script>

<!-- ------------------------------------------------------------------------------------------------------------
    -------------------------------------- FIN ITred Spa Detalle encargado .PHP -----------------------------------
    ------------------------------------------------------------------------------------------------------------- -->

<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITredSpa.
BPPJ
-->