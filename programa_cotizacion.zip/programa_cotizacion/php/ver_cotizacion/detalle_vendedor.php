<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-- ------------------------------------------------------------------------------------------------------------
    ------------------------------------- INICIO ITred Spa Detalle vendedor .PHP --------------------------------------
 ------------------------------------------------------------------------------------------------------------- -->

<!-- TÍTULO: IMPORTACIÓN DE ARCHIVO .CSS -->

    <!-- Llama al archivo CSS -->
    <link rel="stylesheet" href="../../css/ver_cotizacion/detalle_vendedor.css">


 <div class="section">
    <h3>DETALLES DEL VENDEDOR</h3>
    <div class="info">
        <p><strong>Nombre:</strong> <?php echo $nombre_vendedor; ?></p>
        <p><strong>Email:</strong> <?php echo $email_vendedor; ?></p>
        <p><strong>Teléfono:</strong> <?php echo $fono_vendedor; ?></p>
        <p><strong>Celular:</strong> <?php echo $celular_vendedor; ?></p>
    </div>
</div>

<!-------------------------------------------------------------------------->

<!-- TITULO: IMPORTACION DE ARCHIVO .JS -->

    <!-- Llama al archivo JS -->
    <script src="../../js/ver_cotizacion/detalle_vendedor.js"></script> 

<!------------------------------------------------------------------------------------->

<!-- ------------------------------------------------------------------------------------------------------------
    -------------------------------------- FIN ITred Spa Detalle vendedor .PHP -----------------------------------
    ------------------------------------------------------------------------------------------------------------- -->

<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITredSpa.
BPPJ
-->