<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-- ------------------------------------------------------------------------------------------------------------
    ------------------------------------- INICIO ITred Spa Detalle cliente .PHP --------------------------------------
 ------------------------------------------------------------------------------------------------------------- -->

<!-- TITULO: AQUÍ INICIA EL HTML -->

    <!-- INICIO HTML -->
 
<!-- TÍTULO: IMPORTACIÓN DE ARCHIVO .CSS -->
    <!-- Llama al archivo CSS -->
<link rel="stylesheet" href="../../../../css/menu_principal/crear_nuevo/ver_cotizacion/detalle_cliente.css">

<!---------- DETALLE DEL CLIENTE -------->
 <div class="section">
    <h3>DETALLES DEL CLIENTE</h3>
    <div class="info">
        <p><strong>Nombre:</strong> <?php echo $nombre_cliente; ?></p>
        <p><strong>RUT:</strong> <?php echo $rut_cliente; ?></p>
        <p><strong>Dirección:</strong> <?php echo $direccion_cliente; ?></p>
        <p><strong>Teléfono:</strong> <?php echo $telefono_cliente; ?></p>
        <p><strong>Email:</strong> <?php echo $email_cliente; ?></p>
        <p><strong>Giro:</strong> <?php echo $giro_cliente; ?></p>
        <p><strong>Comuna:</strong> <?php echo $comuna_cliente; ?></p>
        <p><strong>Ciudad:</strong> <?php echo $ciudad_cliente; ?></p>
    </div>
</div>

<!-- TÍTULO: IMPORTACIÓN DE ARCHIVO .JS -->
    <!-- Llama al archivo JS -->
    <script src="../../../../js/menu_principal/crear_nuevo/ver_cotizacion/detalle_cliente.js"></script> 

<!-- ------------------------------------------------------------------------------------------------------------
    -------------------------------------- FIN ITred Spa Detalle cliente .PHP -----------------------------------
    ------------------------------------------------------------------------------------------------------------- -->

<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITredSpa.
BPPJ
-->