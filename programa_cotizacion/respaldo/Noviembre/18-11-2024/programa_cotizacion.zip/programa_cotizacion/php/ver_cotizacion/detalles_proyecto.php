<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITred Spa.
BPPJ
-->

<!-- ------------------------------------------------------------------------------------------------------------
    ------------------------------------- INICIO ITred Spa Detalles proyecto .PHP --------------------------------------
 ------------------------------------------------------------------------------------------------------------- -->

<!-- TITULO: IMPORTACIÓN DE ARCHIVO .CSS -->

    <!-- Llama al archivo CSS -->
    <link rel="stylesheet" href="../../css/ver_cotizacion/detalles_proyecto.css">


 <div class="section">
    <h3>DETALLES DEL PROYECTO</h3>
    <div class="info">
        <p><strong>Nombre:</strong> <?php echo $nombre_proyecto; ?></p>
        <p><strong>Código:</strong> <?php echo $codigo_proyecto; ?></p>
        <p><strong>Tipo de trabajo:</strong> <?php echo $tipo_trabajo; ?></p>
        <p><strong>Área de trabajo:</strong> <?php echo $area_trabajo; ?></p>
        <p><strong>Riesgo:</strong> <?php echo $riesgo_proyecto; ?></p>
    </div>
</div>

<!-- TITULO: IMPORTACION DE ARCHIVO .JS -->

    <!-- Llama al archivo JS -->
    <script src="../../js/ver_cotizacion/detalles_proyecto.js"></script>


<!-- ------------------------------------------------------------------------------------------------------------
    -------------------------------------- FIN ITred Spa Detalles proyecto .PHP -----------------------------------
    ------------------------------------------------------------------------------------------------------------- -->

<!--
Sitio Web Creado por ITred Spa.
Direccion: Guido Reni #4190
Pedro Aguirre Cerda - Santiago - Chile
contacto@itred.cl o itred.spa@gmail.com
https://www.itred.cl
Creado, Programado y Diseñado por ITredSpa.
BPPJ
-->